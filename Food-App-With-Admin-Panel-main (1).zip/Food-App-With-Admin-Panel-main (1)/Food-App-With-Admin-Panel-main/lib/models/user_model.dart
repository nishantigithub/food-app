class UserModel {
  String userName;
  String userEmail;
  String userImage;
  String userUid;
  UserModel({
    this.userEmail,
    this.userImage,
    this.userName,
    this.userUid,
  });
}
